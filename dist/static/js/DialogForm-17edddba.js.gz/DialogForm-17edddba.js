import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-7c4f1751.js";import"./message-677c060a.js";import"./index-d0232ddc.js";export{o as default};
