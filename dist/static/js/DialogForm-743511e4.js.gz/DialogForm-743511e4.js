import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-e68e0911.js";import"./message-a2fcb54f.js";import"./index-b7689871.js";export{o as default};
