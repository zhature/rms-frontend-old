import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-039f572c.js";import"./message-2e7cc4d3.js";import"./index-e9572a3e.js";export{o as default};
