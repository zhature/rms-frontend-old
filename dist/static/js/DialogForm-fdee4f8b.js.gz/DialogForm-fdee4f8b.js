import{_ as o}from"./DialogForm.vue_vue_type_script_setup_true_lang-dc8f0466.js";import"./message-aa642c6b.js";import"./index-16ff979f.js";export{o as default};
