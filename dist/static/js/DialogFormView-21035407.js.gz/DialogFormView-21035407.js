import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-f2b582fc.js";import"./index-16ff979f.js";export{m as default};
