import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-cd6b11a3.js";import"./index-e9572a3e.js";export{m as default};
