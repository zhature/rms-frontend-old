import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-5c90cfb9.js";import"./index-d0232ddc.js";export{m as default};
