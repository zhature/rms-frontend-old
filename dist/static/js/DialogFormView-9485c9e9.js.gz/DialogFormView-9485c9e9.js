import{_ as m}from"./DialogFormView.vue_vue_type_script_setup_true_lang-88108f73.js";import"./index-b7689871.js";export{m as default};
