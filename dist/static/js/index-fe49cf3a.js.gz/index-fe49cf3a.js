import{d as e,o,c as t}from"./index-d0232ddc.js";const c=e({name:"Welcome"}),r=e({...c,setup(n){return(a,_)=>(o(),t("h1",null,"Welcome！"))}});export{r as default};
