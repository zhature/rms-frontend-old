import{ay as r}from"./index-e9572a3e.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
