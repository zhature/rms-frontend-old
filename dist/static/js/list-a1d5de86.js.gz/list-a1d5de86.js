import{ay as r}from"./index-b7689871.js";const e=t=>r.request("post","/getCardList",{data:t});export{e as g};
